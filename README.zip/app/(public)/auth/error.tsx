// pages/auth/error.tsx

import { useRouter } from 'next/router';

const ErrorPage = () => {
    const router = useRouter();
    const { error } = router.query;

    let errorMessage = "An unknown error occurred";
    if (error === "Configuration") {
        errorMessage = "There was a configuration error. Please contact support.";
    } else if (error === "AccessDenied") {
        errorMessage = "Access Denied. You do not have permission to access this resource.";
    } else if (error === "Verification") {
        errorMessage = "The verification request is invalid or has expired.";
    } else if (error === "CredentialsSignin") {
        errorMessage = "Sign in failed. Check your credentials and try again.";
    }

    return (
        <div>
            <h1>Authentication Error</h1>
            <p>{errorMessage}</p>
        </div>
    );
};

export default ErrorPage;
